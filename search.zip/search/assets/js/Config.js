app.constant('Config',{
	baseJSON: 'data/',
	tipo: 'get'
})